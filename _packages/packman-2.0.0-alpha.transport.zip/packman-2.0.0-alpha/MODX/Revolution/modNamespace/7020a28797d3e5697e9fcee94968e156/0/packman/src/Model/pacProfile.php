<?php
namespace PackMan\Model;

use xPDO\xPDO;

/**
 * Class pacProfile
 *
 * @property string $name
 * @property string $description
 * @property array $data
 *
 * @package PackMan\Model
 */
class pacProfile extends \xPDO\Om\xPDOSimpleObject
{
}

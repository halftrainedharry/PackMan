----------------------------
Extension: PackMan
----------------------------
Version: 1.2.1
Since: June 11th, 2010
Author: Shaun McCormick <shaun@modxcms.com>
License: GNU GPLv2 (or later at your option)

This component is an assistance tool for building transport
packages for your Templates, Snippets, Chunks and more.

Simply run the manager page, select the appropriate options,
and click Export Transport Package. The file will then be downloaded to your
browser.

Thanks for using MODx Revolution.

Shaun McCormick
shaun@modxcms.com
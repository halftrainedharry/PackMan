<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'PackMan\\Model',
    'namespacePrefix' => 'PackMan',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'PackMan\\Model\\pacProfile',
        ),
    ),
);